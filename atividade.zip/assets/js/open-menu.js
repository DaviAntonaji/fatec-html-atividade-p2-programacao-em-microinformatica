
    function openMenu() {
        var x = document.getElementById("navbar");
        if (x.className === "topnav") {
            x.className += " responsive";
        } else {
            x.className = "topnav";
        }
    }
